import pandas as pd

def load_features(path, prefix):
    x = pd.read_csv(path)
    x["target"] = pd.to_datetime(x["target"]).dt.normalize()
    keys = ["symbol", "target"]
    assert not x.duplicated(keys).any()
    cols = [c for c in x if c.startswith("feature_")]
    return x[keys + cols].rename(
        columns={c: prefix + c for c in cols})

news = load_features("news/daily_features.csv", "news_")
reddit = load_features("reddit/daily_features.csv", "reddit_")
# base: team model table, one row per symbol + target
base["target"] = pd.to_datetime(base["target"]).dt.normalize()
joined = base.merge(news, on=["symbol", "target"],
                    how="left", validate="one_to_one")
joined = joined.merge(reddit, on=["symbol", "target"],
                      how="left", validate="one_to_one")
