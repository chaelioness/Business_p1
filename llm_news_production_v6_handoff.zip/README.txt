뉴스 v6
기대·예상 표현 및 기업명 필터를 통과한 뉴스의 피처.
relevant_share 분모: 성공 기사.
나머지 share 분모: 관련성이 direct 또는 indirect인 성공 기사.
다중 사건 분류이므로 사건 비율 합계는 1을 넘을 수 있음.
우선 relevant_share와 surprise 피처를 평가하고 사건·상태는 추가 검수.


공통 사용법
- symbol + target으로 결합. target은 예측 대상 거래일.
- observed_*: 성공한 표본만으로 계산.
- feature_*: 선택된 표본이 해당 날짜에 전부 성공했을 때만 값 제공.
- complete는 선택 표본의 처리 완료이며 전체 원문 처리 완료라는 뜻이 아님.
- 실패/미처리/후보 없음은 중립이나 0으로 바꾸지 않음.
- llm_*와 상태 컬럼은 품질 확인용. 모델 입력에 자동 포함하지 않음.
- valid_articles.csv는 검수용, excluded_rows.csv는 제외 내역.
- 의미 정확성 및 모델 성능 개선은 별도 검증이 필요.
- 뉴스와 Reddit을 합칠 때 피처에 각각 news_, reddit_ 접두어를 붙일 것.
- 최종 제출에는 이 CSV 외에 재현 코드 및 API 없는 추론 구성이 필요.
