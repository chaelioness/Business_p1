
Reddit v4 DEV 피쳐

모델: gemini-3.1-flash-lite
대상일: 2024-08-14 ~ 2026-05-29
마지막 기준일: 2026-05-28
입력: Reddit 제목만 사용. 본문·댓글·좋아요·정답 사용 안 함.
시간 조건: 직전 거래일 16:00 ET 이상, 대상일 09:30 ET 미만.
선택: 기업명·티커 후보 중 종목·날짜별 서로 다른 제목 최대 3개.
선택 순서: SHA256 고정 순서. 전체 게시글을 모두 분석한 것은 아님.

[사용법]
daily_features.csv를 symbol + target으로 평가 데이터에 결합.
feature_*는 해당 종목·날짜의 선택 요청이 전부 검증에 통과했을 때 제공.
observed_*는 성공한 일부 결과로 계산한 검수용 비율.
partial_or_failed의 observed_*를 완전한 피쳐와 동일하게 취급하지 말 것.
no_candidate, 오류, 미처리를 0이나 중립으로 바꾸지 말 것.

[분모]
relevance 비율: 유효한 선택 게시글 전체.
나머지 비율: relevance=direct인 유효한 선택 게시글.
분모가 없으면 결측 유지.

[파일]
valid_posts.csv: 검증 통과 결과와 원문 근거.
excluded_rows.csv: 오류·응답 불명·미처리 행.
daily_features.csv: 종목·대상일별 집계 피쳐.
plan.json: 실제 프롬프트·모델·스키마·선택 기준.

형식·근거 검증 통과가 의미 해석의 정확성까지 보장하지는 않음.
6월 이후 홀드아웃은 사용하지 않음.
